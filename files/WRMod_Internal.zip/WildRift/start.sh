#!/bin/bash
clear

if [ "$(id -u)" -ne 0 ]; then
    echo "Need Root Access"
    exit 1
fi

TMP_DIR="/data/local/tmp"

# Tự tìm package Wild Rift
if pm path "com.riotgames.league.wildrift" >/dev/null 2>&1; then
    PACKAGE_NAME="com.riotgames.league.wildrift"
elif pm path "com.riotgames.league.wildriftvn" >/dev/null 2>&1; then
    PACKAGE_NAME="com.riotgames.league.wildriftvn"
else
    echo "WILD RIFT not found"
    exit 1
fi

echo "Package: $PACKAGE_NAME"

# Mở game
monkey -p "$PACKAGE_NAME" -c android.intent.category.LAUNCHER 2
sleep 7

# Inject
su -c "./login -pkg \"$PACKAGE_NAME\" -lib \"libeth.so\" -dl_memfd -hide_maps"